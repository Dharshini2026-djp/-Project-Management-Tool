// =============================================
// server.js - Main entry point for the backend
// =============================================

const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const cors = require('cors');

// Import route files
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const taskRoutes = require('./routes/tasks');

const app = express();

// ─── Configuration ────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/projectmanager';
const SESSION_SECRET = process.env.SESSION_SECRET || 'your-secret-key-change-in-production';

// ─── Connect to MongoDB ───────────────────────────────────────────────────────
mongoose
  .connect(MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch((err) => console.error('❌ MongoDB connection error:', err));

// ─── Middleware ───────────────────────────────────────────────────────────────

// Allow requests from the React frontend running on port 3000
app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true, // Allow cookies/sessions to be sent
  })
);

// Parse incoming JSON request bodies
app.use(express.json());

// Session setup — stores login state on the server (in MongoDB)
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: MONGO_URI }), // Save sessions in MongoDB
    cookie: {
      maxAge: 1000 * 60 * 60 * 24, // 1 day in milliseconds
      httpOnly: true,               // Prevents JS access to cookie (security)
    },
  })
);

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);         // /api/auth/register, /api/auth/login, /api/auth/logout
app.use('/api/projects', projectRoutes);  // /api/projects
app.use('/api/tasks', taskRoutes);        // /api/tasks

// ─── Health check route ───────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({ message: 'Project Management API is running!' });
});

// ─── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
