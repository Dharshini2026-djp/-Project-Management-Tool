// =============================================
// routes/tasks.js - CRUD for tasks
// =============================================

const express = require('express');
const router = express.Router();
const Task = require('../models/Task');
const Project = require('../models/Project');
const requireAuth = require('../middleware/requireAuth');

// All task routes require the user to be logged in
router.use(requireAuth);

// ─── GET /api/tasks/:projectId ────────────────────────────────────────────────
// Get all tasks for a specific project
router.get('/:projectId', async (req, res) => {
  try {
    // Verify the project belongs to the logged-in user first
    const project = await Project.findOne({
      _id: req.params.projectId,
      owner: req.session.userId,
    });

    if (!project) {
      return res.status(404).json({ message: 'Project not found.' });
    }

    // Get all tasks for this project
    const tasks = await Task.find({ project: req.params.projectId }).sort({
      createdAt: -1,
    });

    res.json(tasks);
  } catch (err) {
    console.error('Get tasks error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── POST /api/tasks ──────────────────────────────────────────────────────────
// Create a new task for a project
router.post('/', async (req, res) => {
  try {
    const { title, description, status, projectId } = req.body;

    if (!title || !projectId) {
      return res.status(400).json({ message: 'Title and projectId are required.' });
    }

    // Verify the project belongs to the logged-in user
    const project = await Project.findOne({
      _id: projectId,
      owner: req.session.userId,
    });

    if (!project) {
      return res.status(404).json({ message: 'Project not found.' });
    }

    const task = new Task({
      title,
      description: description || '',
      status: status || 'To Do',
      project: projectId,
      owner: req.session.userId,
    });

    await task.save();
    res.status(201).json(task);
  } catch (err) {
    console.error('Create task error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── PUT /api/tasks/:id ───────────────────────────────────────────────────────
// Update a task (title, description, or status)
router.put('/:id', async (req, res) => {
  try {
    const { title, description, status } = req.body;

    // Find the task and verify it belongs to the logged-in user
    const task = await Task.findOne({
      _id: req.params.id,
      owner: req.session.userId,
    });

    if (!task) {
      return res.status(404).json({ message: 'Task not found.' });
    }

    // Update only the fields that were provided
    if (title !== undefined) task.title = title;
    if (description !== undefined) task.description = description;
    if (status !== undefined) task.status = status;

    await task.save();
    res.json(task);
  } catch (err) {
    console.error('Update task error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── DELETE /api/tasks/:id ────────────────────────────────────────────────────
// Delete a task
router.delete('/:id', async (req, res) => {
  try {
    const task = await Task.findOne({
      _id: req.params.id,
      owner: req.session.userId,
    });

    if (!task) {
      return res.status(404).json({ message: 'Task not found.' });
    }

    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted successfully.' });
  } catch (err) {
    console.error('Delete task error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
