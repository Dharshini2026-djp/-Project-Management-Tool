// =============================================
// middleware/requireAuth.js
// Protects routes that need a logged-in user
// =============================================

// This function runs before protected route handlers
// If the user is not logged in, it sends a 401 error
// If logged in, it calls next() to continue to the actual route

function requireAuth(req, res, next) {
  // req.session.userId is set when the user logs in (see auth.js)
  if (!req.session.userId) {
    return res.status(401).json({ message: 'You must be logged in to do that.' });
  }
  next(); // User is logged in, proceed to the route
}

module.exports = requireAuth;
