// =============================================
// components/Navbar.js
// =============================================
// The top navigation bar shown after login.
// Displays the app logo, user name, and logout button.

import React from 'react';
import { logout } from '../api';

function Navbar({ user, onLogout }) {
  // Handle logout button click
  const handleLogout = async () => {
    try {
      await logout();   // Tell the server to destroy the session
      onLogout();       // Tell the parent (App.js) to clear user state
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* Logo */}
        <span className="navbar-logo">
          Project<span>Flow</span>
        </span>

        {/* Right side: user name + logout */}
        <div className="navbar-right">
          <span className="navbar-user">👤 {user.name}</span>
          <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
