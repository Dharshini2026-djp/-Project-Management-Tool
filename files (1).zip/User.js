// =============================================
// models/User.js - Mongoose schema for users
// =============================================

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Define what a User looks like in the database
const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true, // Remove extra whitespace
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,      // No two users can have the same email
      lowercase: true,   // Store email in lowercase
      trim: true,
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters'],
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// ─── Before saving, hash the password ────────────────────────────────────────
// This "pre" hook runs automatically before every save() call
userSchema.pre('save', async function (next) {
  // Only hash if password was changed (avoids re-hashing on other updates)
  if (!this.isModified('password')) return next();

  // bcrypt salt rounds: higher = more secure but slower (10 is a good balance)
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// ─── Method to compare passwords at login ────────────────────────────────────
// Call this as: user.comparePassword('plainTextPassword')
userSchema.methods.comparePassword = async function (plainPassword) {
  return bcrypt.compare(plainPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
