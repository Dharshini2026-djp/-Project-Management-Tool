// =============================================
// pages/DashboardPage.js - Project Dashboard
// =============================================
// Shows all of the user's projects.
// Lets them create new projects and delete existing ones.
// Clicking a project navigates to that project's tasks.

import React, { useState, useEffect } from 'react';
import { getProjects, createProject, deleteProject } from '../api';

function DashboardPage({ user, onOpenProject }) {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // New project form state
  const [showForm, setShowForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [creating, setCreating] = useState(false);
  const [formError, setFormError] = useState('');

  // ─── Load projects on mount ─────────────────────
  useEffect(() => {
    loadProjects();
  }, []); // Empty array = run once when component mounts

  const loadProjects = async () => {
    try {
      setLoading(true);
      const data = await getProjects();
      setProjects(data);
    } catch (err) {
      setError('Failed to load projects. Please refresh.');
    } finally {
      setLoading(false);
    }
  };

  // ─── Create a new project ───────────────────────
  const handleCreate = async (e) => {
    e.preventDefault();
    if (!newName.trim()) {
      setFormError('Project name is required.');
      return;
    }
    setCreating(true);
    setFormError('');
    try {
      const project = await createProject(newName.trim(), newDesc.trim());
      // Add the new project to the top of the list
      setProjects([project, ...projects]);
      // Reset form
      setNewName('');
      setNewDesc('');
      setShowForm(false);
    } catch (err) {
      setFormError(err.message);
    } finally {
      setCreating(false);
    }
  };

  // ─── Delete a project ───────────────────────────
  const handleDelete = async (e, projectId) => {
    e.stopPropagation(); // Prevent triggering the card click (which opens the project)
    if (!window.confirm('Delete this project and all its tasks? This cannot be undone.')) return;

    try {
      await deleteProject(projectId);
      // Remove the project from state
      setProjects(projects.filter((p) => p._id !== projectId));
    } catch (err) {
      alert('Failed to delete project.');
    }
  };

  // Format a date like "Mar 15, 2024"
  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

  return (
    <div className="dashboard-main">
      {/* Header */}
      <div className="dashboard-header">
        <div>
          <div className="dashboard-greeting">Dashboard</div>
          <h1>Your Projects</h1>
        </div>
        <button
          className="btn btn-primary"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? '✕ Cancel' : '+ New Project'}
        </button>
      </div>

      {/* New Project Form (shown/hidden by toggle) */}
      {showForm && (
        <div className="new-project-panel">
          <h3>Create New Project</h3>
          {formError && <div className="alert alert-error" style={{ marginBottom: '14px' }}>{formError}</div>}
          <form className="new-project-form" onSubmit={handleCreate}>
            <div className="form-group">
              <label className="form-label">Project Name *</label>
              <input
                className="form-input"
                type="text"
                placeholder="e.g. Website Redesign"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                className="form-textarea"
                placeholder="What is this project about? (optional)"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                rows={3}
              />
            </div>
            <div className="form-row">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setShowForm(false)}
              >
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={creating}>
                {creating ? 'Creating...' : 'Create Project'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Error state */}
      {error && <div className="alert alert-error">{error}</div>}

      {/* Loading state */}
      {loading ? (
        <div className="loading-wrapper">
          <div className="spinner" />
        </div>
      ) : (
        /* Projects grid */
        <div className="projects-grid">
          {projects.length === 0 ? (
            /* Empty state */
            <div className="empty-state">
              <span className="empty-icon">📋</span>
              <h3>No projects yet</h3>
              <p>Create your first project to get started</p>
              <button className="btn btn-primary" onClick={() => setShowForm(true)}>
                + New Project
              </button>
            </div>
          ) : (
            /* Project cards */
            projects.map((project) => (
              <div
                key={project._id}
                className="project-card"
                onClick={() => onOpenProject(project)} // Navigate to task view
              >
                <div className="project-card-name">{project.name}</div>
                <div className="project-card-desc">
                  {project.description || 'No description provided.'}
                </div>
                <div className="project-card-footer">
                  <span className="project-card-date">
                    Created {formatDate(project.createdAt)}
                  </span>
                  <div className="project-card-actions">
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={(e) => handleDelete(e, project._id)}
                      title="Delete project"
                    >
                      🗑 Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default DashboardPage;
