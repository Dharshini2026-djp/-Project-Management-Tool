// =============================================
// models/Project.js - Mongoose schema for projects
// =============================================

const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Project name is required'],
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      default: '',
    },
    // Each project belongs to one user
    // We store the user's MongoDB _id here
    owner: {
      type: mongoose.Schema.Types.ObjectId, // References the User collection
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Project', projectSchema);
