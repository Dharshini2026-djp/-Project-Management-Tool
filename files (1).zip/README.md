# ProjectFlow — MERN Project Management Tool

A beginner-friendly, full-stack project management app built with MongoDB, Express, React, and Node.js.

---

## What You Can Do

- Register and log in with a secure account
- Create, view, and delete projects from your dashboard
- Add tasks to any project with a title, description, and status
- Edit tasks and update their status (To Do → In Progress → Done)
- See tasks grouped in a visual Kanban-style board
- Log out and your session is cleared securely

---

## Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | React.js (Create React App), plain CSS |
| Backend   | Node.js + Express.js              |
| Database  | MongoDB + Mongoose ODM            |
| Auth      | Server-side sessions (express-session) |
| Passwords | bcryptjs (hashed, never plain text) |

---

## Folder Structure

```
project-management-tool/
├── backend/
│   ├── models/
│   │   ├── User.js          # User schema (name, email, hashed password)
│   │   ├── Project.js       # Project schema (name, description, owner)
│   │   └── Task.js          # Task schema (title, status, project ref)
│   ├── routes/
│   │   ├── auth.js          # POST /register, /login, /logout, GET /me
│   │   ├── projects.js      # GET, POST, DELETE /api/projects
│   │   └── tasks.js         # GET, POST, PUT, DELETE /api/tasks
│   ├── middleware/
│   │   └── requireAuth.js   # Protects routes that need a login
│   ├── server.js            # App entry point
│   ├── .env.example         # Environment variable template
│   └── package.json
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── pages/
    │   │   ├── AuthPage.js      # Login + Register forms
    │   │   ├── DashboardPage.js # Project list + create/delete
    │   │   └── TasksPage.js     # Kanban board for a project's tasks
    │   ├── components/
    │   │   ├── Navbar.js        # Top nav with logout
    │   │   └── TaskModal.js     # Create/edit task modal dialog
    │   ├── styles/
    │   │   └── global.css       # All styles (no frameworks)
    │   ├── api.js               # All fetch() calls to the backend
    │   ├── App.js               # Root component + navigation logic
    │   └── index.js             # React entry point
    └── package.json
```

---

## Prerequisites

Make sure you have these installed before starting:

1. **Node.js** (v16 or later) — https://nodejs.org
   - Verify: `node --version`
2. **npm** (comes with Node.js)
   - Verify: `npm --version`
3. **MongoDB** (Community Edition) — https://www.mongodb.com/try/download/community
   - On Mac with Homebrew: `brew tap mongodb/brew && brew install mongodb-community`
   - Verify it's running: `mongod --version`

---

## Setup & Run (Step-by-Step)

### Step 1 — Start MongoDB

**On macOS/Linux:**
```bash
# Start MongoDB as a background service
brew services start mongodb-community
# OR run it directly:
mongod --dbpath ~/data/db
```

**On Windows:**
```bash
# Start the MongoDB service
net start MongoDB
```

You should see MongoDB running on port 27017.

---

### Step 2 — Set Up the Backend

Open a terminal and run:

```bash
# 1. Navigate into the backend folder
cd project-management-tool/backend

# 2. Install all dependencies
npm install

# 3. Create your environment file
#    (copy the example and edit if needed)
cp .env.example .env

# 4. Start the backend server
npm start
```

You should see:
```
✅ Connected to MongoDB
🚀 Server running on http://localhost:5000
```

Leave this terminal open and running.

---

### Step 3 — Set Up the Frontend

Open a **second terminal** and run:

```bash
# 1. Navigate into the frontend folder
cd project-management-tool/frontend

# 2. Install all dependencies
npm install

# 3. Start the React development server
npm start
```

Your browser will automatically open to **http://localhost:3000**

---

### Step 4 — Use the App

1. **Register** a new account with your name, email, and password
2. You'll be logged in automatically and taken to the **Dashboard**
3. Click **+ New Project** to create your first project
4. Click on any project card to open its **Task Board**
5. Click **+ Add Task** to create tasks and assign them a status
6. Use the dropdown on each task to move it between columns
7. Use ✏️ Edit to update task details, 🗑 to delete

---

## API Endpoints Reference

### Auth
| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| POST   | /api/auth/register    | Create a new account         |
| POST   | /api/auth/login       | Log in                       |
| POST   | /api/auth/logout      | Log out (destroys session)   |
| GET    | /api/auth/me          | Get currently logged-in user |

### Projects (all require login)
| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| GET    | /api/projects         | Get all your projects         |
| POST   | /api/projects         | Create a new project          |
| DELETE | /api/projects/:id     | Delete a project + its tasks  |

### Tasks (all require login)
| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| GET    | /api/tasks/:projectId | Get all tasks for a project   |
| POST   | /api/tasks            | Create a new task             |
| PUT    | /api/tasks/:id        | Update a task (title/status)  |
| DELETE | /api/tasks/:id        | Delete a task                 |

---

## How Authentication Works

This app uses **server-side sessions** — a simple alternative to JWT tokens that's great for beginners:

1. When you log in, the server creates a **session** and stores your user ID in it
2. The session ID is saved in a **cookie** in your browser
3. Every time you make a request, the cookie is sent automatically
4. The server looks up the session to know who you are
5. When you log out, the session is destroyed on the server

Sessions are stored in MongoDB using `connect-mongo` so they survive server restarts.

---

## Common Issues & Fixes

**"Cannot connect to MongoDB"**
- Make sure MongoDB is running: `brew services list` or check Windows Services
- Check that port 27017 is not blocked

**"CORS error" in browser console**
- Make sure both servers are running (backend on :5000, frontend on :3000)
- The `"proxy": "http://localhost:5000"` in frontend/package.json handles this

**"npm install" fails**
- Try deleting `node_modules/` and running `npm install` again
- Make sure you're using Node.js v16+

**Sessions not persisting after restart**
- This is normal in development if you change the SESSION_SECRET in .env
- Existing sessions become invalid when the secret changes

---

## Extending the App (Ideas for Practice)

- Add a **due date** field to tasks
- Add **task priority** (Low / Medium / High)
- Add **drag-and-drop** between Kanban columns
- Add a **search bar** to filter tasks
- Add **project-level stats** (task count by status)
- Add **JWT authentication** instead of sessions
- Deploy to **Railway** (backend) + **Vercel** (frontend)

---

## License

MIT — free to use and modify for learning purposes.
