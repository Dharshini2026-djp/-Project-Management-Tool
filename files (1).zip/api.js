// =============================================
// api.js - Helper functions for all API calls
// =============================================
// Instead of writing fetch() everywhere, we put all
// API calls here. This keeps components clean and
// easy to update if the API changes.

const BASE = '/api'; // The proxy in package.json forwards this to localhost:5000

// ─── Helper: Make a fetch request and handle errors ──
async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // Important: sends the session cookie with every request
    ...options,
  });

  const data = await res.json();

  if (!res.ok) {
    // Throw an error with the message from the server
    throw new Error(data.message || 'Something went wrong.');
  }

  return data;
}

// ─── Auth ──────────────────────────────────────────
export const register = (name, email, password) =>
  request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });

export const login = (email, password) =>
  request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

export const logout = () =>
  request('/auth/logout', { method: 'POST' });

export const getMe = () =>
  request('/auth/me');

// ─── Projects ──────────────────────────────────────
export const getProjects = () =>
  request('/projects');

export const createProject = (name, description) =>
  request('/projects', {
    method: 'POST',
    body: JSON.stringify({ name, description }),
  });

export const deleteProject = (id) =>
  request(`/projects/${id}`, { method: 'DELETE' });

// ─── Tasks ─────────────────────────────────────────
export const getTasks = (projectId) =>
  request(`/tasks/${projectId}`);

export const createTask = (title, description, status, projectId) =>
  request('/tasks', {
    method: 'POST',
    body: JSON.stringify({ title, description, status, projectId }),
  });

export const updateTask = (id, updates) =>
  request(`/tasks/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });

export const deleteTask = (id) =>
  request(`/tasks/${id}`, { method: 'DELETE' });
