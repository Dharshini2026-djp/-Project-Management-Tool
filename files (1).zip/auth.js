// =============================================
// routes/auth.js - Register, Login, Logout
// =============================================

const express = require('express');
const router = express.Router();
const User = require('../models/User');

// ─── POST /api/auth/register ──────────────────────────────────────────────────
// Creates a new user account
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Basic validation
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    // Check if email is already taken
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email is already registered.' });
    }

    // Create the user (password is hashed automatically by the model's pre-save hook)
    const user = new User({ name, email, password });
    await user.save();

    // Log them in right after registration by saving their ID in the session
    req.session.userId = user._id;
    req.session.userName = user.name;

    res.status(201).json({
      message: 'Account created successfully!',
      user: { id: user._id, name: user.name, email: user.email },
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
// Logs in an existing user
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required.' });
    }

    // Find the user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password.' });
    }

    // Compare the entered password with the stored hashed password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password.' });
    }

    // Save user info in session (this is how we "remember" the logged-in user)
    req.session.userId = user._id;
    req.session.userName = user.name;

    res.json({
      message: 'Login successful!',
      user: { id: user._id, name: user.name, email: user.email },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

// ─── POST /api/auth/logout ────────────────────────────────────────────────────
// Logs out the current user by destroying their session
router.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'Could not log out. Try again.' });
    }
    res.clearCookie('connect.sid'); // Clear the session cookie from the browser
    res.json({ message: 'Logged out successfully.' });
  });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
// Returns the currently logged-in user (used to restore session on page refresh)
router.get('/me', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: 'Not logged in.' });
  }
  try {
    const user = await User.findById(req.session.userId).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found.' });
    res.json({ user: { id: user._id, name: user.name, email: user.email } });
  } catch (err) {
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
