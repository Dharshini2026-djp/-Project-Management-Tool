// =============================================
// models/Task.js - Mongoose schema for tasks
// =============================================

const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Task title is required'],
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      default: '',
    },
    // Task status — one of three values
    status: {
      type: String,
      enum: ['To Do', 'In Progress', 'Done'], // Only these values are allowed
      default: 'To Do',
    },
    // Each task belongs to one project
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
    },
    // Each task also tracks which user created it
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Task', taskSchema);
