// =============================================
// App.js - Root Component & Navigation
// =============================================
// This is the top-level component. It:
//   1. Checks if the user is logged in (session)
//   2. Decides which "page" to show based on state
//   3. Passes data and callbacks down to child pages

import React, { useState, useEffect } from 'react';
import { getMe } from './api';

import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import TasksPage from './pages/TasksPage';
import Navbar from './components/Navbar';

import './styles/global.css';

function App() {
  // The currently logged-in user object (null if not logged in)
  const [user, setUser] = useState(null);

  // The project the user has opened (null = show dashboard)
  const [activeProject, setActiveProject] = useState(null);

  // True while we're checking if the user is already logged in
  const [checkingAuth, setCheckingAuth] = useState(true);

  // ─── On app load, check if there's an active session ──
  // This restores the session after a page refresh.
  useEffect(() => {
    const checkSession = async () => {
      try {
        const data = await getMe();
        setUser(data.user); // User is already logged in
      } catch {
        setUser(null); // No active session — show login page
      } finally {
        setCheckingAuth(false);
      }
    };
    checkSession();
  }, []);

  // ─── Show loading screen while checking auth ──────────
  if (checkingAuth) {
    return (
      <div className="loading-wrapper" style={{ minHeight: '100vh' }}>
        <div className="spinner" />
      </div>
    );
  }

  // ─── Not logged in → show Auth page ──────────────────
  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  // ─── Logged in → show Navbar + the appropriate page ──
  return (
    <div className="page-wrapper">
      <Navbar user={user} onLogout={() => { setUser(null); setActiveProject(null); }} />

      {activeProject ? (
        // A project is open → show its tasks
        <TasksPage
          project={activeProject}
          onBack={() => setActiveProject(null)}
        />
      ) : (
        // No project open → show dashboard
        <DashboardPage
          user={user}
          onOpenProject={setActiveProject}
        />
      )}
    </div>
  );
}

export default App;
