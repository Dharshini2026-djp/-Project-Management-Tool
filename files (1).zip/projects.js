// =============================================
// routes/projects.js - CRUD for projects
// =============================================

const express = require('express');
const router = express.Router();
const Project = require('../models/Project');
const Task = require('../models/Task');
const requireAuth = require('../middleware/requireAuth');

// All project routes require the user to be logged in
router.use(requireAuth);

// ─── GET /api/projects ────────────────────────────────────────────────────────
// Get all projects belonging to the logged-in user
router.get('/', async (req, res) => {
  try {
    // Only fetch projects where owner matches the logged-in user
    const projects = await Project.find({ owner: req.session.userId }).sort({
      createdAt: -1, // Newest first
    });
    res.json(projects);
  } catch (err) {
    console.error('Get projects error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── POST /api/projects ───────────────────────────────────────────────────────
// Create a new project
router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Project name is required.' });
    }

    const project = new Project({
      name,
      description: description || '',
      owner: req.session.userId, // Assign to logged-in user
    });

    await project.save();
    res.status(201).json(project);
  } catch (err) {
    console.error('Create project error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

// ─── DELETE /api/projects/:id ─────────────────────────────────────────────────
// Delete a project and all its tasks
router.delete('/:id', async (req, res) => {
  try {
    // Find the project and make sure it belongs to the logged-in user
    const project = await Project.findOne({
      _id: req.params.id,
      owner: req.session.userId,
    });

    if (!project) {
      return res.status(404).json({ message: 'Project not found.' });
    }

    // Delete the project
    await Project.findByIdAndDelete(req.params.id);

    // Also delete all tasks that belong to this project (cleanup)
    await Task.deleteMany({ project: req.params.id });

    res.json({ message: 'Project deleted successfully.' });
  } catch (err) {
    console.error('Delete project error:', err);
    res.status(500).json({ message: 'Server error.' });
  }
});

module.exports = router;
