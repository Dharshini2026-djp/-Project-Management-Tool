// =============================================
// pages/TasksPage.js - Task Board for a Project
// =============================================
// Displays all tasks for a selected project,
// grouped into three columns by status.

import React, { useState, useEffect } from 'react';
import { getTasks, createTask, updateTask, deleteTask } from '../api';
import TaskModal from '../components/TaskModal';

// The three columns and their display settings
const COLUMNS = [
  { status: 'To Do',       key: 'col-todo',     label: 'To Do'       },
  { status: 'In Progress', key: 'col-progress',  label: 'In Progress' },
  { status: 'Done',        key: 'col-done',      label: 'Done'        },
];

function TasksPage({ project, onBack }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Modal state: null = closed, 'create' = new task, task object = editing
  const [modal, setModal] = useState(null);

  // ─── Load tasks on mount ────────────────────────
  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      setLoading(true);
      const data = await getTasks(project._id);
      setTasks(data);
    } catch (err) {
      setError('Failed to load tasks.');
    } finally {
      setLoading(false);
    }
  };

  // ─── Create a new task ──────────────────────────
  const handleCreate = async ({ title, description, status }) => {
    const task = await createTask(title, description, status, project._id);
    setTasks([task, ...tasks]);
  };

  // ─── Update an existing task ────────────────────
  const handleUpdate = async ({ title, description, status }) => {
    const updated = await updateTask(modal._id, { title, description, status });
    // Replace the old task in state with the updated one
    setTasks(tasks.map((t) => (t._id === updated._id ? updated : t)));
  };

  // ─── Quick status change (without opening modal) ─
  const handleStatusChange = async (task, newStatus) => {
    try {
      const updated = await updateTask(task._id, { status: newStatus });
      setTasks(tasks.map((t) => (t._id === updated._id ? updated : t)));
    } catch (err) {
      alert('Failed to update status.');
    }
  };

  // ─── Delete a task ──────────────────────────────
  const handleDelete = async (taskId) => {
    if (!window.confirm('Delete this task?')) return;
    try {
      await deleteTask(taskId);
      setTasks(tasks.filter((t) => t._id !== taskId));
    } catch (err) {
      alert('Failed to delete task.');
    }
  };

  // Filter tasks by their status column
  const getTasksForColumn = (status) =>
    tasks.filter((t) => t.status === status);

  // Status options for the quick-move dropdown
  const OTHER_STATUSES = ['To Do', 'In Progress', 'Done'];

  return (
    <div className="task-page-main">
      {/* Back button */}
      <button className="back-btn" onClick={onBack}>
        ← Back to Dashboard
      </button>

      {/* Page header */}
      <div className="task-page-header">
        <div>
          <h2>{project.name}</h2>
          {project.description && (
            <p style={{ marginTop: '6px' }}>{project.description}</p>
          )}
        </div>
        <button
          className="btn btn-primary"
          onClick={() => setModal('create')}
        >
          + Add Task
        </button>
      </div>

      {/* Error */}
      {error && <div className="alert alert-error" style={{ marginTop: '16px' }}>{error}</div>}

      {/* Loading */}
      {loading ? (
        <div className="loading-wrapper">
          <div className="spinner" />
        </div>
      ) : (
        /* Task board — 3 columns */
        <div className="task-board">
          {COLUMNS.map((col) => {
            const colTasks = getTasksForColumn(col.status);
            return (
              <div key={col.status} className={`task-column ${col.key}`}>
                {/* Column header */}
                <div className="task-column-header">
                  <div className="column-title">
                    <span className="column-dot" />
                    {col.label}
                  </div>
                  <span className="column-count">{colTasks.length}</span>
                </div>

                {/* Tasks in this column */}
                {colTasks.length === 0 ? (
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: '24px' }}>
                    No tasks here
                  </p>
                ) : (
                  colTasks.map((task) => (
                    <div key={task._id} className="task-card">
                      <div className="task-card-title">{task.title}</div>
                      {task.description && (
                        <div className="task-card-desc">{task.description}</div>
                      )}

                      {/* Quick status mover */}
                      <div style={{ marginTop: '10px' }}>
                        <select
                          className="form-select"
                          style={{ fontSize: '0.78rem', padding: '5px 30px 5px 8px' }}
                          value={task.status}
                          onChange={(e) => handleStatusChange(task, e.target.value)}
                          title="Move to..."
                        >
                          {OTHER_STATUSES.map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </div>

                      {/* Edit / Delete buttons */}
                      <div className="task-card-actions">
                        <button
                          className="btn btn-ghost btn-sm"
                          onClick={() => setModal(task)}
                          title="Edit task"
                        >
                          ✏️ Edit
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(task._id)}
                          title="Delete task"
                        >
                          🗑
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Task Modal (create or edit) */}
      {modal && (
        <TaskModal
          task={modal === 'create' ? null : modal}
          onSave={modal === 'create' ? handleCreate : handleUpdate}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}

export default TasksPage;
