// =============================================
// index.js - React Entry Point
// =============================================
// This file mounts the React app into the HTML page.
// It targets the <div id="root"> in public/index.html.

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
